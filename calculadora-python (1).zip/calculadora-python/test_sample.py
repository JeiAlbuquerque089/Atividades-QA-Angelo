from app import adicao, subtracao, multiplicacao, divisao, fatorial, potencia


def test_adicao():
    assert adicao(2, 3) == 5
    assert adicao(-1, 1) == 0
    assert adicao(0, 0) == 0

def test_subtracao():
    assert subtracao(5, 3) == 2
    assert subtracao(-1, 1) == -2
    assert subtracao(0, 0) == 0

def test_multiplicacao():
    assert multiplicacao(2, 3) == 6
    assert multiplicacao(-1, 1) == -1
    assert multiplicacao(0, 100) == 0

def test_divisao():
    assert divisao(6, 3) == 2
    assert divisao(-6, 2) == -3
    assert divisao(0, 1) == 0
    assert divisao(5, 0) == "Erro: Divisão por zero não é permitida."

def test_fatorial():
    assert fatorial(5) == 120
    assert fatorial(0) == 1
    assert fatorial(1) == 1
    assert fatorial(-5) == "Erro: Não é possível calcular fatorial de número negativo."

def test_potencia():
    assert potencia(2, 3) == 8
    assert potencia(5, 0) == 1
    assert potencia(2, -2) == 0.25
    assert potencia(0, 5) == 0
