# Calculadora com Testes Unitários

Este projeto implementa uma calculadora simples em Python com as operações básicas: adição, subtração, multiplicação, divisão (com tratamento de divisão por zero), fatorial (com tratamento de números negativos) e potência. O projeto também inclui testes unitários escritos usando `pytest -s test_sample.py`.

## Pré-requisitos

Antes de começar, você vai precisar ter as seguintes ferramentas instaladas em sua máquina:

- [Python 3.x](https://www.python.org/downloads/)
- [pip](https://pip.pypa.io/en/stable/installation/) (gerenciador de pacotes do Python)
- [virtualenv](https://virtualenv.pypa.io/en/latest/) (opcional, mas recomendado para isolar o ambiente do projeto)

## Configuração do Ambiente

Siga os passos abaixo para configurar o ambiente localmente:

### 1. Crie um ambiente virtual

```bash
$ python -m venv venv
```

### 2. Ative o ambiente virtual
````
$ source venv/bin/activate
````
### 3. Instale as dependências do projeto
```bash
$ pip install -r requirements.txt
```

## Executando a Calculadora
```bash
$ python app.py
```

## Executando os Testes
```bash
$ pytest -s test_sample.py
```