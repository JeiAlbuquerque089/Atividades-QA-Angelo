import math

def adicao(num1, num2):
    return num1 + num2

def subtracao(num1, num2):
    return num1 - num2


def multiplicacao(num1, num2):
    return num1 * num2


def divisao(num1, num2):
    if num2 == 0:
        return "Erro: Divisão por zero não é permitida."
    return num1 / num2

def fatorial(num):
    if num < 0:
        return "Erro: Não é possível calcular fatorial de número negativo."
    return math.factorial(num)

def potencia(base, expoente):
    return base ** expoente

def calculadora():
    while True:
        print("\nEscolha a operação:")
        print("1. Adição")
        print("2. Subtração")
        print("3. Multiplicação")
        print("4. Divisão")
        print("5. Fatorial")
        print("6. Potência")
        print("0. Sair")

        escolha = input("Digite o número da operação: ")

        if escolha == '0':
            print("Encerrando a calculadora.")
            break

        if escolha in ['1', '2', '3', '4', '6']:
            num1 = float(input("Digite o primeiro número: "))
            num2 = float(input("Digite o segundo número: "))

            if escolha == '1':
                print(f"Resultado: {adicao(num1, num2)}")
            elif escolha == '2':
                print(f"Resultado: {subtracao(num1, num2)}")
            elif escolha == '3':
                print(f"Resultado: {multiplicacao(num1, num2)}")
            elif escolha == '4':
                print(f"Resultado: {divisao(num1, num2)}")
            elif escolha == '6':
                print(f"Resultado: {potencia(num1, num2)}")

        elif escolha == '5':
            num = int(input("Digite um número para calcular o fatorial: "))
            print(f"Resultado: {fatorial(num)}")
        else:
            print("Opção inválida, tente novamente.")

calculadora()
